define('translation:widget/translate/favo/commonCollGroup/commonCollGroup.jsx', function(require, exports, module) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
      value: true
  });
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  exports.createCommonCollGroup = createCommonCollGroup;
  exports.destroyCommonCollGroup = destroyCommonCollGroup;
  
  var _react = require('translation:node_modules/react/index');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactDom = require('translation:node_modules/react-dom/index');
  
  var _reactCustomScrollbars = require('translation:node_modules/react-custom-scrollbars/lib/index');
  
  var _classnames = require('translation:node_modules/classnames/index');
  
  var _classnames2 = _interopRequireDefault(_classnames);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  * @file 输入框收藏夹列表
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  * @author yaowei02@baidu.com
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  */
  
  var env = require('translation:widget/common/environment');
  var collInfo = require('translation:widget/translate/favo/collInfo');
  var collGroupUtil = require('translation:widget/common/collGroupUtil');
  var getDisplayLength = require('translation:widget/common/util').getDisplayLength;
  
  var CommonCollGroup = function (_Component) {
      _inherits(CommonCollGroup, _Component);
  
      function CommonCollGroup() {
          var _ref;
  
          var _temp, _this, _ret;
  
          _classCallCheck(this, CommonCollGroup);
  
          for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
              args[_key] = arguments[_key];
          }
  
          return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = CommonCollGroup.__proto__ || Object.getPrototypeOf(CommonCollGroup)).call.apply(_ref, [this].concat(args))), _this), _this.closeErrMsgTimeOut = null, _this.state = {
              showNewGroupInput: false,
              inputText: '',
              errText: ''
          }, _this.newGroupAndAddColl = function () {
              if (_this.state.inputText.trim().length > 0) {
                  var name = _this.state.inputText;
                  collGroupUtil.newCollGroupAsync(name, false).then(function (gid) {
                      // 修改分组数据
                      env.get('collInfo').groupList.push({ name: name, id: gid, nameDisplayLength: getDisplayLength(name) });
                      // 收藏
                      _this.props.favorInstance.add(gid);
                  }, function (errMsg) {
                      if (_this.closeErrMsgTimeOut) {
                          clearTimeout(closeErrMsgTimeOut);
                      }
                      _this.setState({
                          errText: '\u521B\u5EFA\u5931\u8D25\uFF1A' + errMsg
                      });
                      setTimeout(function () {
                          _this.setState({
                              errText: ''
                          });
                      }, 2000);
                  });
              }
          }, _temp), _possibleConstructorReturn(_this, _ret);
      }
  
      _createClass(CommonCollGroup, [{
          key: 'render',
          value: function render() {
              var _this2 = this;
  
              var _state = this.state,
                  showNewGroupInput = _state.showNewGroupInput,
                  inputText = _state.inputText,
                  errText = _state.errText;
              var favorInstance = this.props.favorInstance;
  
              return _react2.default.createElement(
                  _react2.default.Fragment,
                  null,
                  _react2.default.createElement(
                      'div',
                      { className: 'input-coll-group-container' },
                      _react2.default.createElement('a', {
                          onClick: function onClick(e) {
                              // 自己销毁自己
                              destroyCommonCollGroup({
                                  containerEle: $(e.target).closest('.common-coll-group-container')[0],
                                  favorInstance: favorInstance
                              });
                          },
                          className: 'close-input-coll-group' }),
                      _react2.default.createElement(
                          'header',
                          { className: 'gray' },
                          '\u6DFB\u52A0\u6536\u85CF\u5230\xA0',
                          _react2.default.createElement(
                              'span',
                              { className: 'black' },
                              '(\u5355\u9009)'
                          ),
                          '\xA0\uFF1A'
                      ),
                      _react2.default.createElement('hr', null),
                      _react2.default.createElement(
                          _reactCustomScrollbars.Scrollbars,
                          {
                              autoHide: true,
                              autoHeight: true,
                              autoHeightMax: 160 },
                          env.get('collInfo').groupList.map(function (_ref2) {
                              var nameDisplayLength = _ref2.nameDisplayLength,
                                  name = _ref2.name,
                                  id = _ref2.id;
                              return _react2.default.createElement(
                                  'li',
                                  {
                                      onClick: function onClick() {
                                          favorInstance.add(id);
                                      },
                                      key: id,
                                      className: 'input-coll-li',
                                      title: nameDisplayLength > 14 ? name : '' },
                                  name
                              );
                          })
                      ),
                      _react2.default.createElement('hr', null),
                      _react2.default.createElement(
                          'div',
                          { className: 'new-coll-group-container' },
                          _react2.default.createElement(
                              'a',
                              {
                                  onClick: function onClick() {
                                      _this2.setState({
                                          showNewGroupInput: true
                                      });
                                  },
                                  style: { display: showNewGroupInput ? 'none' : 'block' },
                                  className: 'add-new-group' },
                              '\u65B0\u6536\u85CF\u5206\u7EC4'
                          ),
                          _react2.default.createElement(
                              'div',
                              {
                                  style: { display: !showNewGroupInput ? 'none' : 'block' },
                                  className: 'new-coll-group-input-container' },
                              _react2.default.createElement('input', {
                                  onChange: function onChange(e) {
                                      _this2.setState({
                                          inputText: e.target.value
                                      });
                                  },
                                  value: inputText,
                                  type: 'text',
                                  placeholder: '\u8BF7\u8F93\u5165\u65B0\u5206\u7EC4\u540D\u79F0',
                                  className: 'new-group-name'
                              }),
                              _react2.default.createElement(
                                  'a',
                                  {
                                      onKeyDown: function onKeyDown(e) {
                                          if (parseInt(e.keyCode, 10) === 13) {
                                              e.preventDefault();
                                              _this2.newGroupAndAddColl();
                                              return false;
                                          }
                                      },
                                      onClick: this.newGroupAndAddColl,
                                      className: (0, _classnames2.default)('new-group-confirm', {
                                          'disabled-new-group-confirm': inputText.trim().length === 0
                                      }) },
                                  '\u521B\u5EFA\u5E76\u6DFB\u52A0'
                              )
                          )
                      )
                  ),
                  _react2.default.createElement(
                      'div',
                      {
                          style: { display: errText.length > 0 ? 'block' : 'none' },
                          className: 'new-coll-group-err-msg' },
                      errText
                  )
              );
          }
      }]);
  
      return CommonCollGroup;
  }(_react.Component);
  
  function createCommonCollGroup(_ref3) {
      var containerEle = _ref3.containerEle,
          favorInstance = _ref3.favorInstance;
  
      collInfo.getCollGroupListAsync().then(function () {
          console.log(containerEle);
          (0, _reactDom.render)(_react2.default.createElement(CommonCollGroup, {
              favorInstance: favorInstance
          }), containerEle);
          favorInstance.$btn.addClass('op-favo-hover');
      });
  }
  
  function destroyCommonCollGroup(_ref4) {
      var containerEle = _ref4.containerEle,
          favorInstance = _ref4.favorInstance;
  
      (0, _reactDom.unmountComponentAtNode)(containerEle);
      favorInstance.$btn.removeClass('op-favo-hover');
  }
  
  // 点空白收起
  $(document).on('click', function (e) {
      var $target = $(e.target);
      var $commonFavorContainer = $('.common-favor-container');
      if (!$target.is($commonFavorContainer) && $commonFavorContainer.has($target).length === 0) {
          $commonFavorContainer.each(function (idx, favorContainerEle) {
              destroyCommonCollGroup({
                  containerEle: $(favorContainerEle).find('.common-coll-group-container')[0],
                  favorInstance: { $btn: $(favorContainerEle).find('.op-favo') }
              });
          });
      }
  });

});

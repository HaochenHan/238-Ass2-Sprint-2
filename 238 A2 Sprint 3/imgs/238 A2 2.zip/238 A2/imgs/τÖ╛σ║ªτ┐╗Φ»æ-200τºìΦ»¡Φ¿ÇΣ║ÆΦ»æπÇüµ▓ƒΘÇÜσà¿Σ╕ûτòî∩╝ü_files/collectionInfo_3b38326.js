define("translation:widget/redux/collectionInfo/collectionInfo",function(e,n){"use strict";function r(e){if(Array.isArray(e)){for(var n=0,r=Array(e.length);n<e.length;n++)r[n]=e[n];
return r}return Array.from(e)}function t(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{defaultGroupId:window.defaultGid,groupList:[]},n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=n.type,a=n.payload;
switch(t){case c:return i({},e,{defaultGroupId:a});case l:var o=a.id,u=a.name,d=[].concat(r(e.groupList)),f=d.findIndex(function(e){var n=e.id;
return n===o});return-1!==f&&d.splice(f,1),i({},e,{groupList:[].concat(r(d),[{id:o,name:u}])});case p:var g=a,m=[].concat(r(e.groupList)),v=m.findIndex(function(e){var n=e.id;
return n===g});return-1!==v&&m.splice(v,1),i({},e,{groupList:m});case s:var y=a.oldId,I=a.newId,w=a.newName,G=[].concat(r(e.groupList)),L=G.findIndex(function(e){var n=e.id;
return n===y});return-1!==L&&G.splice(L,1,{id:"number"==typeof I?I:y,name:w?w:G[L].name}),i({},e,{groupList:G});default:return e
}}function a(e){var n=e.id,r=e.name;return{type:l,payload:{id:n,name:r}}}function o(e){return{type:p,payload:e}}function u(e){var n=e.oldId,r=e.newId,t=e.newName;
return{type:s,payload:{oldId:n,newId:r,newName:t}}}function d(e){return{type:c,payload:e}}Object.defineProperty(n,"__esModule",{value:!0});
var i=Object.assign||function(e){for(var n=1;n<arguments.length;n++){var r=arguments[n];for(var t in r)Object.prototype.hasOwnProperty.call(r,t)&&(e[t]=r[t])
}return e};n.collectionInfo=t,n.addGroup=a,n.deleteGroup=o,n.updateGroup=u,n.updateDefaultGroupId=d;var c="UPDATE_DEFAULT_GROUP_ID",l="ADD_GROUP",p="DELETE_GROUP",s="UPDATE_GROUP"
});
define("translation:widget/redux/indexInfo/indexInfo",function(e,n){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.indexInfo=void 0;
{var o=e("translation:node_modules/redux/lib/redux"),d=e("translation:widget/redux/indexInfo/noteInfo");n.indexInfo=o.combineReducers({noteInfo:d.noteInfo})
}});
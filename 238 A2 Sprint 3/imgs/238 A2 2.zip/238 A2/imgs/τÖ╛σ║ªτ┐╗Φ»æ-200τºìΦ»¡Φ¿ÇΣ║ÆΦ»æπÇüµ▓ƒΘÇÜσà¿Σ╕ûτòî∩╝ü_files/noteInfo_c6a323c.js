define("translation:widget/redux/indexInfo/noteInfo",function(e,t){"use strict";function n(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{showNotePanel:!1,noteContent:"",reportContent:"",hasModified:!1},t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},n=t.type,o=t.payload;
switch(n){case s:return"boolean"==typeof o.showNotePanel&&$(".note-expand-btn").toggleClass("to-close",o.showNotePanel),r({},e,o);
default:return e}}function o(e){return{type:s,payload:e}}function a(){return{type:s,payload:{showNotePanel:!1,noteContent:"",reportContent:"",hasModified:!1}}
}Object.defineProperty(t,"__esModule",{value:!0});var r=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];
for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(e[o]=n[o])}return e};t.noteInfo=n,t.updateNoteInfo=o,t.clearNoteInfo=a;
var s="UPDATE_NOTE_INFO"});
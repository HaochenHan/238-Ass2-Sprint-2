define('translation:widget/translate/output/NotePanel/NotePanel.jsx', function(require, exports, module) {

  'use strict';
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('translation:node_modules/react/index');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactDom = require('translation:node_modules/react-dom/index');
  
  var _reactRedux = require('translation:node_modules/react-redux/lib/index');
  
  var _store = require('translation:widget/redux/store');
  
  var _store2 = _interopRequireDefault(_store);
  
  var _noteInfo = require('translation:widget/redux/indexInfo/noteInfo');
  
  var _reactCustomScrollbars = require('translation:node_modules/react-custom-scrollbars/lib/index');
  
  var _reactAutosizeTextarea = require('translation:node_modules/react-autosize-textarea/lib/index');
  
  var _reactAutosizeTextarea2 = _interopRequireDefault(_reactAutosizeTextarea);
  
  var _classnames = require('translation:node_modules/classnames/index');
  
  var _classnames2 = _interopRequireDefault(_classnames);
  
  var _login = require('translation:widget/login/login');
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  * @file
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  * @author 姚伟 <yaowei02@baidu.com>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  */
  
  var inputFavo = require('translation:widget/translate/input/inputFavo');
  
  var NotePanel = function (_Component) {
      _inherits(NotePanel, _Component);
  
      function NotePanel() {
          var _ref,
              _this2 = this;
  
          var _temp, _this, _ret;
  
          _classCallCheck(this, NotePanel);
  
          for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
              args[_key] = arguments[_key];
          }
  
          return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = NotePanel.__proto__ || Object.getPrototypeOf(NotePanel)).call.apply(_ref, [this].concat(args))), _this), _this.onSaveClick = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this$props, isLogin, showNotePanel, noteContent, hasModified, updateNoteInfo;
  
              return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                      switch (_context.prev = _context.next) {
                          case 0:
                              _this$props = _this.props, isLogin = _this$props.isLogin, showNotePanel = _this$props.showNotePanel, noteContent = _this$props.noteContent, hasModified = _this$props.hasModified, updateNoteInfo = _this$props.updateNoteInfo;
  
                              if (hasModified) {
                                  _context.next = 3;
                                  break;
                              }
  
                              return _context.abrupt('return');
  
                          case 3:
                              _context.next = 5;
                              return (0, _login.ensureUserLoginAsync)();
  
                          case 5:
                              inputFavo.saveNote(noteContent);
                              updateNoteInfo({
                                  hasModified: false
                              });
  
                          case 7:
                          case 'end':
                              return _context.stop();
                      }
                  }
              }, _callee, _this2);
          })), _temp), _possibleConstructorReturn(_this, _ret);
      }
  
      _createClass(NotePanel, [{
          key: 'render',
          value: function render() {
              var _props = this.props,
                  showNotePanel = _props.showNotePanel,
                  noteContent = _props.noteContent,
                  hasModified = _props.hasModified,
                  updateNoteInfo = _props.updateNoteInfo;
  
              return _react2.default.createElement(
                  'div',
                  {
                      style: {
                          display: showNotePanel ? 'block' : 'none'
                      },
                      className: 'notePanel' },
                  _react2.default.createElement(
                      _reactCustomScrollbars.Scrollbars,
                      {
                          style: {
                              width: '100%',
                              height: 194
                          }
                      },
                      _react2.default.createElement(_reactAutosizeTextarea2.default, {
                          rows: 7,
                          onChange: function onChange(e) {
                              updateNoteInfo({
                                  noteContent: e.target.value.substring(0, 1000),
                                  hasModified: true
                              });
                          },
                          placeholder: '\u5728\u6B64\u8F93\u5165\u4F60\u7684\u7B14\u8BB0',
                          value: noteContent,
                          className: 'noteTextarea'
                      })
                  ),
                  _react2.default.createElement(
                      'div',
                      { className: 'noteBottomArea' },
                      _react2.default.createElement(
                          'div',
                          { className: 'noteWordCount' },
                          noteContent.length,
                          ' / 1000'
                      ),
                      _react2.default.createElement(
                          'a',
                          { 'data-stat-id': '105',
                              onClick: this.onSaveClick,
                              className: (0, _classnames2.default)('saveBtn', {
                                  'saveBtnDisable': !hasModified
                              }) },
                          '\u4FDD\u5B58\u5E76\u540C\u6B65\u6536\u85CF\u5939'
                      )
                  )
              );
          }
      }, {
          key: 'componentDidUpdate',
          value: function componentDidUpdate(prevProps, prevState, snapshot) {
              if (this.props.showNotePanel && !prevProps.showNotePanel) {
                  window._hmt.push(['_trackEvent', '首页', '107_首页页面_笔记展开态展现量']);
              }
          }
      }]);
  
      return NotePanel;
  }(_react.Component);
  
  var ConnectedNotePanel = (0, _reactRedux.connect)(function (_ref3) {
      var isLogin = _ref3.baseInfo.isLogin,
          _ref3$indexInfo$noteI = _ref3.indexInfo.noteInfo,
          showNotePanel = _ref3$indexInfo$noteI.showNotePanel,
          noteContent = _ref3$indexInfo$noteI.noteContent,
          hasModified = _ref3$indexInfo$noteI.hasModified;
      return {
          isLogin: isLogin,
          showNotePanel: showNotePanel,
          noteContent: noteContent,
          hasModified: hasModified
      };
  }, function (dispatch) {
      return {
          updateNoteInfo: function updateNoteInfo() {
              return dispatch(_noteInfo.updateNoteInfo.apply(undefined, arguments));
          }
      };
  })(NotePanel);
  
  (0, _reactDom.render)(_react2.default.createElement(
      _reactRedux.Provider,
      { store: _store2.default },
      _react2.default.createElement(ConnectedNotePanel, null)
  ), document.getElementById('noteContainer'));
  
  // 给笔记按钮绑定事件
  $('.output-wrap').on('click', '.note-expand-btn', function (e) {
      var _store$getState = _store2.default.getState(),
          isLogin = _store$getState.baseInfo.isLogin,
          showNotePanel = _store$getState.indexInfo.noteInfo.showNotePanel;
      /* globals _hmt */
  
  
      if (!isLogin && !showNotePanel) {
          (0, _login.newLoginInstanceAsync)();
          _hmt.push(['_trackEvent', '首页', '115_首页页面_点击笔记调起登录']);
          return;
      } else if (isLogin && !showNotePanel) {
          _hmt.push(['_trackEvent', '首页', '116_首页页面_点击笔记成功登录']);
      }
      _store2.default.dispatch((0, _noteInfo.updateNoteInfo)({
          showNotePanel: !showNotePanel
      }));
  });

});
